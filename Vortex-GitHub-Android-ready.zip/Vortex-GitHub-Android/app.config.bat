@echo off
REM Vortex Engine Android output configuration
set "APP_NAME=Vortex Game"
set "PACKAGE_NAME=com.vortex.engine.game"
set "VERSION_NAME=1.0.0"
set "VERSION_CODE=1"
set "APK_NAME=Vortex-Game-1.0.0.apk"
set "ICON_FILE=assets\icon.png"
