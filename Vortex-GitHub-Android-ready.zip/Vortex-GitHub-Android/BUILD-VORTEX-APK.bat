@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" (
  echo.
  echo Drag the generated Vortex Game HTML file onto this BAT.
  echo It will be copied to www\index.html and then the APK build starts.
  echo.
  pause
  exit /b 1
)
if not exist "%~1" (
  echo ERROR: Input HTML was not found.
  pause
  exit /b 1
)
copy /Y "%~1" "www\index.html" >nul
if errorlevel 1 (
  echo ERROR: Could not copy the game HTML into www\index.html
  pause
  exit /b 1
)
echo Vortex Game copied to www\index.html
call "BUILD-APK.bat"
