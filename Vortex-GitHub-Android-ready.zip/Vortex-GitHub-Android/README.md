# Vortex Game — GitHub Android Builder

This repository contains the Vortex Engine web game and a GitHub Actions workflow that builds it as an Android APK with Capacitor.

## Automatic APK build

1. Upload this folder to a GitHub repository.
2. Push it to the `main` branch, or open **Actions → Build Vortex Game Android APK → Run workflow**.
3. Wait for the workflow to finish.
4. Open the completed workflow run and download the **Vortex-Game-Android** artifact.

The APK is built from `www/index.html`. The editor UI is not packaged as a separate desktop editor; the HTML app is the game payload used by the Android WebView.

## GitHub Release

Create a tag such as `v1.0.0` and push it. The release workflow creates a GitHub Release and attaches the debug APK.

## Windows local build

You can also use `BUILD-VORTEX-APK.bat` or `BUILD-APK.bat` on Windows when Node.js and a JDK are installed.
